from . import algebra
from . import trigonometry
from . import calculus
from . import quadratics_math
from . import graphics

pi = 3,1415926535897932384626433832795
e = 2,7182818284590452353602874713527

__version__ = "1.0.0"
def show_version():
    print(f"InfinityMath version: {__version__}")