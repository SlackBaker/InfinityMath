import InfinityMath.algebra
from InfinityMath import algebra
from InfinityMath import trigonometry
from InfinityMath import calculus
from InfinityMath import graphics
from InfinityMath import quadratics_math

print(InfinityMath.__version__)
#get version

print(InfinityMath.algebra.div(2,5))
print(InfinityMath.algebra.pow(3,5))
# You can use sqrt, sum, substarction and other functions below

